# Algorithm

- Leer archivo con lenguaje de prueba a.k.a. cadenas
- Buscar matches con expresiones regulares
- Segun la expresion con la que hizo match, concatenar el mensaje correspondiente al estado con el coincidente
- 

https://witeboard.com/e0695ec0-bfd3-11ed-a0fb-9bc1770e5ee7